clear all;
close all;



A=0.02;
f=50;
N=5;
RB1=110;
RB2=10;
RC=4;
RE=1;
beta=100;
VAl=15;
tip=1;

emitorcomun(A,f,N,RB1,RB2,RC,RE,beta,VAl,tip);